export { default as Details } from './Details/Details';
export { default as Main } from './Main/Main';
export { default as Snackbar } from './Snackbar/Snackbar';
export { default as InfoCard } from './InfoCard';
